<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Tasty Food</title>
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
</head>
<body>
    <header>
        <h1>Tasty Food</h1>
        <nav>
            <a href="/">Home</a>
            <a href="/tentang">Tentang</a>
            <a href="/kontak">Kontak</a>
        </nav>
    </header>
