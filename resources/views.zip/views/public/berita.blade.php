@extends('layout')

@section('title', 'Home')

@section('content')
    <h2>Selamat datang di Tasty Food!</h2>
    <p>Ini adalah halaman beranda.</p>
@endsection
