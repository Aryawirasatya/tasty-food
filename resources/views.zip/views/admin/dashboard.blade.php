@include('admin.layouts.header')

@section('title', 'Dashboard')

<h1>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Alias odit autem dolorum veritatis laudantium illum reiciendis iure, vero recusandae quas, nobis excepturi. Inventore assumenda tempora modi suscipit natus id quo!</h1>

@include('admin.layouts.footer')
